class Chart {
    constructor(options) {    
      this.containerId = options.containerId;
      this.type = options.type;
      this.title = options.title;
      this.subtitle = options.subtitle;
      this.xAxis = options.xAxis;
      this.yAxisFormat = options.yAxisFormat;
      this.tooltipFormatter = options.tooltipFormatter;
      this.creditsText = options.creditsText;
      this.creditsHref = options.creditsHref;
      this.series = options.series;
      this.colors = options.colors;
      this.legend = options.legend;
      this.columnOptions = options.columnOptions;
      this.pieOptions = options.pieOptions;
      this.seriesOptions = options.seriesOptions;
      this.yAxisTitle = options.yAxisTitle;
    }



    createChart() {
      const chartContainer = document.getElementById("chart");

      // Destroy any existing Highcharts chart in this container
      const existingChart = Highcharts.charts.find(chart => chart && chart.renderTo && chart.renderTo.id === 'chart');
      if (existingChart) {
        existingChart.destroy();
      }

      if (chartContainer && !chartContainer.hasAttribute('tabindex')) {
        // Highcharts' keyboard-nav module puts tabindex="0" on its own inner
        // .highcharts-container div unless renderTo already has a tabindex -
        // in which case it uses renderTo instead. renderTo already gets
        // role="region"/"group" from the accessibility module, so pre-setting
        // this avoids a focusable element with no ARIA role.
        chartContainer.setAttribute('tabindex', '0');
      }

      const chart = Highcharts.chart("chart", {
        chart: {
          type: this.type,
          plotBackgroundColor: null,
          plotBorderWidth: null,
          plotShadow: false,
          spacingBottom: 70,
          style: {
            fontFamily: 'arial,sans-serif',
            animation: true,
            duration: 1000,
          },
           zooming: {
            mouseWheel: false
        }
        },
        accessibility: {
          // Single chart landmark; avoids duplicate role="region" per series
          landmarkVerbosity: "one",
        },
        title: {
          text: this.title,
        },
        subtitle: {
          text: this.subtitle,
        },
        xAxis: this.xAxis,
        yAxis: {
          labels: {
            format: this.yAxisFormat,
          },
          title: {
            enabled: true,
            text: this.yAxisTitle,            
          },
        },
        colors: this.colors,
        tooltip: {
          formatter: this.tooltipFormatter,
          valueDecimals: 4,
          shared: true,
          useHTML: true,         
          padding: 0, 
        },
       credits: {
          enabled: false,
        },
        legend: this.legend,
        plotOptions: {
          column: this.columnOptions,
          pie: this.pieOptions,
          series: this.seriesOptions,
      },
        series: this.series,
        exporting: {      
          enabled: true,
          allowHTML: true,
          sourceWidth: 1200,
          sourceHeight: 800,
          scale: 1,
          chartOptions: {
            subtitle: null,
            credits:"",
            chart: {
              marginTop: 100,
              marginLeft: 100,
              marginRight: 100,
              events: {
                load: function () {                  
                  this.renderer.image(
                    'https://ec.europa.eu/eurostat/statistics-explained/images/0/09/Logo_RGB-POS.png', 
                    1100, 
                    750, 
                    90, 
                    50
                  ).add();
                },
                redraw: function () {
                  const chart = this;
                  const images = chart.container.getElementsByTagName('image');
                  if (images.length > 0) {
                    images[0].setAttribute('x', chart.chartWidth - 100);
                    images[0].setAttribute('y', chart.chartHeight - 40);
                  }
                }
              }
          } 
          },
                      
          buttons: {
              contextButton: {
                  enabled: false
              }
          }, 
          csv: {
            columnHeaderFormatter: function(item, key) {
                if (!item || item instanceof Highcharts.Axis) {
                  const chartLabels = {
                    "pieChart": languageNameSpace.labels["INDICATOR"],
                    "barChart": languageNameSpace.labels["CTR"],
                    "mainChart": languageNameSpace.labels["CTR"],
                    // Add more chart types and their corresponding labels here
                };                    
                // Default label for unknown chart types
                const defaultLabel = languageNameSpace.labels["YEAR"];  

                const label = chartLabels[REF.chartId] || defaultLabel;
                return label;                   
                } else {
                    return item.name;
                }
            }
        }
      }
      }); // end of chart object
      enableScreenREader()

      // Force the accessibility module to rebuild its keyboard-nav proxies
      // now, rather than relying solely on the legend's own "afterRender"
      // event - avoids a momentarily-empty legend proxy list.
      if (chart.accessibility) {
        chart.accessibility.update();
      }

      // The "end of chart" marker div is a pure announcement (not a
      // control) but Highcharts gives it tabindex without a role.
      const exitMarker = document.getElementById(`highcharts-end-of-chart-marker-${chart.index}`);
      if (exitMarker) {
        exitMarker.setAttribute('role', 'note');
      }

      // The root SVG has an aria-label but no role. Safe to add role="img"
      // here specifically: data points inside the SVG are tabindex="-1"
      // (not real tab stops), and the real keyboard-nav controls (legend/
      // series/zoom proxy buttons) are separate elements outside the SVG.
      if (chart.renderer && chart.renderer.box) {
        chart.renderer.box.setAttribute('role', 'img');
      }

      setTimeout(() => {
        updateAccessibilityLabels()
   
      }, 500);

      // Render custom credits after chart is created
      setTimeout(() => {
        this.renderCustomCredits();
      }, 1000);
    } // end of chart function



         renderCustomCredits() {
      if (!this.creditsText) {
        return;
      }

      // Use hardcoded "chart" ID since that's what's used in createChart()
      const container = document.getElementById('chart');
      if (!container) {
        return;
      }

      const regionId = 'chart-credits-region';
      let creditsWrapper = document.getElementById(regionId);

      if (!creditsWrapper) {
        creditsWrapper = document.createElement('div');
        creditsWrapper.id = regionId;
        creditsWrapper.className = 'chart-credits-region';

        if (container.parentNode) {
          container.parentNode.insertBefore(creditsWrapper, container.nextSibling);
        } else {
          container.appendChild(creditsWrapper);
        }
      }

      // This is supplementary chart-level info; use role="note" rather than a page-level landmark
      creditsWrapper.setAttribute('role', 'note');
      creditsWrapper.setAttribute('aria-label', 'Chart credits');
      creditsWrapper.setAttribute('aria-live', 'polite');
      creditsWrapper.innerHTML = this.creditsText;

      const link = creditsWrapper.querySelector('a');
      if (link) {
        link.setAttribute('tabindex', '0');
        link.addEventListener('keydown', (event) => {
          if (event.key === ' ' || event.key === 'Spacebar') {
            event.preventDefault();
            link.click();
          }
        });
      }
    }

    destroy() {
      // Destroy Highcharts chart
      const existingChart = Highcharts.charts.find(chart => chart && chart.renderTo && chart.renderTo.id === 'chart');
      if (existingChart) {
        existingChart.destroy();
      }
    }


    
  }

  // function that return empty chart for when is no data to display
  function nullishChart() {
    const chartOptions = {
      containerId: "chart",
      type: null,
      title: null,
      subtitle: null,
      xAxis: null,
      yAxisFormat: null,
      tooltipFormatter: null,
      creditsText: "Source: Eurostat",
      creditsHref: "",
      series: [{ data: [] }],
      colors: null,
      legend: true,
      columnOptions: "",
      seriesOptions: ""
    };
  
    const chart = new Chart(chartOptions);
    chart.createChart();
  }
  

  